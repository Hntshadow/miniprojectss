<aside class="app-sidebar">
     
      <ul class="app-menu">
        <li><a class="app-menu__item" href="dashboard.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-building-o"></i><span class="app-menu__label">Brand</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">

            <li><a class="treeview-item" href="add-brand.php"><i class="icon fa fa-circle-o"></i> Add Brand</a></li>
<li><a class="treeview-item" href="manage-brand.php"><i class="icon fa fa-circle-o"></i> Manage Brand</a></li>
       </ul>
        </li>

<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Vehicle</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">

        <li><a class="treeview-item" href="add-vehicle.php"><i class="icon fa fa-circle-o"></i> Add Vehicle</a></li>
<li><a class="treeview-item" href="manage-vehicle.php"><i class="icon fa fa-circle-o"></i> Manage Vehicle</a></li>
       </ul>
        </li>
       
       <li><a class="app-menu__item" href="betdatevehcle-report.php"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Report</span></a></li>
        <li><a class="app-menu__item" href="search-vehicle.php"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Search</span></a></li>
          
     
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-building-o"></i><span class="app-menu__label">Website Setting</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">

            <li><a class="treeview-item" href="about-us.php"><i class="icon fa fa-circle-o"></i> About Us</a></li>
<li><a class="treeview-item" href="contact-us.php"><i class="icon fa fa-circle-o"></i> Contact Us</a></li>
       </ul>
        </li>
      </ul>
    </aside>

   