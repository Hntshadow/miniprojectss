How to run the store-it (Two way Inventory Manegment) Project

1. Download the zip file

2. Extract the file and copy store-it folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/HTML)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name store-it

6. Import store-it.sql file(given inside the zip package in the store-it file folder)

7. Run the script http://localhost/store-it

-------------------------------------------------------

Admin site Store-it
http://localhost/../../store-it/store-it
(Should apear as the path)

Credential for Admin panel :

Username: admin@123
Password: 1234

Create a branch login within admin dashboard or there is the default

-------------------------------------------------------

Branch site Connect Plus
http://localhost/../../store-it/admin
(Should apear as the path)

Credential for Branch panel :

(Default)
Username: stmankan@gmail.com
Password: 1234