<div class="footer-section">
				<div class="container">
					<div class="footer-top">
						<p>&copy; <?php echo date('Y')?> Zoo Management System </p>
					</div>
				</div>
			</div>